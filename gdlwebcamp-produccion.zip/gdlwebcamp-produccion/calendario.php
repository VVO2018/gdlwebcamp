<?php include_once 'includes/templates/header.php'; ?>


    <section class="seccion contenedor">
        <h2>Calendario de eventos</h2>

        <?php
            //---------PROCESO PARA REALIZAR UNA CONEXIÓN CON UNA BASE DE DATOS--------

            //Esto se utiliza porque vamos a hacer una conexión a base de datos
            //En el caso de que por algo no se pueda conectar a la BD, el catch toma el error y la página
            //sigue funcionando pero no mostraría nada de la base de datos.
            try {
                //Esta función es parecida al INCLUDE_ONCE. Es para incluir archivos.
                //Aquí se realiza la conexión a la BD y permite realizar consultas.
                require_once('includes/funciones/bd_conexion.php');
                //Así es como se escribe la consulta
                // $sql = " SELECT * FROM eventos ";
                //Los 4 primeros campos son de la tabla EVENTOS, los campos 5 y 6 son de la tabla CATEGORIA_EVENTO y los campos 7 y 8 son de la tabla INVITADOS.
                $sql = " SELECT evento_id, nombre_evento, fecha_evento, hora_evento, cat_evento, icono, nombre_invitado, apellido_invitado ";
                // .= es porque voy a concatenar
                $sql .= " FROM eventos ";
                //INNER JOIN: es como se unen las dos tablas (eventos y categoria_evento) utilizando un ID
                $sql .= " INNER JOIN categoria_evento ";
                //Aquí decimos cuáles son los campos iguales entre las tablas (llaves foráneas)
                $sql .= " ON eventos.id_cat_evento = categoria_evento.id_categoria ";
                $sql .= " INNER JOIN invitados ";
                $sql .= " ON eventos.id_inv = invitados.invitado_id ";
                $sql .= " ORDER BY evento_id ";
                //QUERY es una función de PHP para hacer una consulta
                //Esta es la variable que hace la consulta a la base de datos
                $resultado = $conn->query($sql);
            } catch (Exception $e) {
                echo $e->getMessage();
            }
        ?>

        <div class="calendario">
            <?php
                $calendario = array();
                //fetch_assoc es una función que imprime los resultados, pero solo el primer arreglo o evento, en este caso
                //por eso se utiliza el while, para que recorra todos los eventos y no muestre solo el primero
                while($eventos = $resultado->fetch_assoc()) {

                    //Obtiene la fecha del evento para agruparlos posteriormente basándose en ella
                    $fecha = $eventos['fecha_evento'];

                    $evento = array(
                        //Aquí estamos "reorganizando" el arreglo $eventos a nuestra manera. Es como formatearlo.
                        'titulo' => $eventos['nombre_evento'],
                        'fecha' => $eventos['fecha_evento'],
                        'hora' => $eventos['hora_evento'],
                        'categoria' => $eventos['cat_evento'],
                        'icono' => $eventos['icono'],
                        'invitado' => $eventos['nombre_invitado'] . " " . $eventos['apellido_invitado']
                    );

                    //Esto es para que agrupe los eventos que son de la MISMA FECHA
                    $calendario[$fecha][] = $evento;

                    // echo "<pre>";
                    // var_dump($eventos);
                    // echo "</pre>";

                    //El arreglo se llama $eventos y accedo a la llave 'nombre_evento'
                    // echo $eventos['nombre_evento'];
                    // echo '<br>';
                }


                //----------------IMPRIME TODOS LOS EVENTOS-------------------

                foreach($calendario as $dia => $lista_eventos) {
                    echo "<h3>";
                    echo '<i class="far fa-calendar-alt"></i> ';

                    //Para cambiar la fecha a español, en Linux o Mac:
                    //setlocale(LC_TIME, 'es_ES.UTF-8');
                    //Para cambiar la fecha a español, en Windows:
                    setlocale(LC_TIME, 'spanish');

                    //date: es una función que ayuda a formatear fechas. F: mes, j: día, Y: año. Pero esta función no deja cambiar el lenguaje de la fecha.
                    //strtotime: convierte un string a fecha
                    //echo date("F j, Y", strtotime($dia));
                    //strftime: se utiliza porque esta función sí deja cambiar el lenguaje de la fecha.
                    //%A: día de la semana. %d: día. %B: mes. %Y: año.
                    //El utf8_encode se agregó para que a la palabra SÁBADO le salga la Á con tilde
                    echo utf8_encode(strftime("%A, %d de %B del %Y", strtotime($dia)));
                    echo "</h3>";

            ?>
                    
                    <?php foreach($lista_eventos as $evento) { ?>
                        <div class="dia">
                            <p class="titulo"> <?php echo $evento['titulo']; ?> </p>
                            <p class="hora">
                                <i class="far fa-clock" aria-hidden="true"></i>
                                <?php echo $evento['fecha'] . " " . $evento['hora']; ?>
                            </p>
                            <p>
                                <i class="fas <?php echo $evento['icono']; ?>" aria-hidden="true"></i>
                                <?php echo $evento['categoria']; ?>
                            </p>
                            <p> 
                                <i class="fas fa-user" aria-hidden="true"></i>
                                <?php echo $evento['invitado']; ?>
                            </p>

                            <!-- <pre>
                                <?php //var_dump($evento); ?>
                            </pre> -->
                        </div>
                        
                    <?php } ?>
                <?php } ?>

        </div> <!-- calendario -->

        <?php
            //Es necesario siempre cerrar la conexión con la BD
            $conn->close();
        ?>

    </section>


<?php include_once 'includes/templates/footer.php'; ?>