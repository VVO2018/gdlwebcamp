<?php
    //Se coloca primero el HOST, luego USUARIO, CONTRASEÑA, BASE DE DATOS y PUERTO
    //Esta es mi variable de conexión
    $conn = new mysqli('localhost', 'root', '', 'gdlwebcamp', 3306);

    //Si ocurre algún error:
    if ($conn->connect_error) {
        echo $error -> $conn->connect_error;
    }
?>