<?php
    //& o Paso por referencia: es para que tome los datos originales de ese arreglo
    //Se pone que las camisas y etiquetas por default tienen un valor de 0 ya que no son obligatorias
    function productos_json(&$boletos, &$camisas = 0, &$etiquetas = 0) {
        $dias = array(0 => 'un_dia', 1 => 'pase_completo', 2 => 'pase_2dias');

        //------------------NUEVO-------------------

        //función que elimina un valor de una variable o de un arreglo
        unset($boletos['un_dia']['precio']);
        unset($boletos['completo']['precio']);
        unset($boletos['2dias']['precio']);

        //------------------NUEVO-------------------

        //Combina arreglos: $dias serán las llaves y $boletos los valores
        $total_boletos = array_combine($dias, $boletos);
        // $json = array();
        // //Función que convierte un array en json
        
        // foreach($total_boletos as $key => $boletos):
        //     //(int) se pone para convertir los strings de $boletos en int
        //     //Este IF se pone para verificar que solo cuando los usuarios seleccionen
        //     //cierta cantidad de boletos, se guarden. Y si no seleccionan boletos, no se guarde un 0.
        //     if((int) $boletos > 0):
        //         //Al json siempre se le pasa lo que será su 'llave' y se le asigna lo que será el(los) valor(es)
        //         $json[$key] = (int) $boletos;
        //     endif;
        // endforeach;

        //Esto es para que solo se guarden estos registros, si no son iguales a 0
        $camisas = (int) $camisas;
        if($camisas > 0):
            // $json['camisas'] = $camisas;
            $total_boletos['camisas'] = $camisas;
        endif;

        $etiquetas = (int) $etiquetas;
        if($etiquetas > 0):
            // $json['etiquetas'] = $etiquetas;
            $total_boletos['etiquetas'] = $etiquetas;
        endif;

        //json_encode: regresa un JSON formateado. Siempre que se quiera utilizar esta función, debe ser con un arreglo.
        // return json_encode($json);
        return json_encode($total_boletos);
    }

    function eventos_json(&$eventos) {
        $eventos_json = array();
        foreach($eventos as $evento):
            //Se le pone otro grupo de corchetes para que muestre todos los eventos
            $eventos_json['eventos'][] = $evento;
        endforeach;

        return json_encode($eventos_json);
    }
?>