<?php
    require 'paypal/autoload.php';

    define('URL_SITIO', 'http://localhost/gdlwebcamp');

    $apiContext = new \PayPal\Rest\ApiContext(
        new \PayPal\Auth\OAuthTokenCredential(
            //ClienteID
            'AZmNe3vTNzN5tu5KMv2Qe-FTvZZmxAl_VKfqgV4QLGidMPjCDemOBToo3fe2FV-K8wAToCw9Zy47dKzC',
            //Secret
            'EC06P5Sr0taGJ9_F4ubQyBbwOJdHMNUQYDerTY_9ifNBGePjZdZBVHU_5WJbmg0S_oarpsThF-xlUajE'
        )
    );

    // var_dump($apiContext);
?>