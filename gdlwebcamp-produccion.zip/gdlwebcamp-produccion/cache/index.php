
<!doctype html>
<html class="no-js" lang="">

<head>
    <meta charset="utf-8">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="manifest" href="site.webmanifest">
    <link rel="apple-touch-icon" href="icon.png">
    <!-- Place favicon.ico in the root directory -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css" integrity="sha512-NhSC1YmyruXifcj/KFRWoC561YpHpc5Jtzgvbuzx5VozKpWvQ+4nXhPdFgmx8xqexRcpAglTj9sIBWINXa8x5w==" crossorigin="anonymous" />
    <!-- Este es el link de FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" integrity="sha512-L7MWcK7FNPcwNqnLdZq86lTHYLdQqZaz5YcAgE+5cnGmlw8JT03QB2+oxL100UeB6RlzZLUxCGSS4/++mNZdxw==" crossorigin="anonymous" />
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&family=Oswald&family=PT+Sans:wght@400;700&display=swap" rel="stylesheet">

    <!-- Link al CSS de leaflet para el mapa -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.6.0/dist/leaflet.css" />

    <link rel="stylesheet" href="css/colorbox.css">
    <!-- Link al CSS del plugin COLORBOX -->
    
    <link rel="stylesheet" href="css/main.css">

    <meta name="theme-color" content="#fafafa">
</head>

<body class="index">
    <!--[if IE]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
  <![endif]-->

    <header class="site-header">
        <div class="hero">
            <div class="contenido-header">
                <nav class="redes-sociales">
                    <a href=""><i class="fab fa-facebook-f"></i></a>
                    <a href=""><i class="fab fa-twitter"></i></a>
                    <a href=""><i class="fab fa-pinterest-p"></i></a>
                    <a href=""><i class="fab fa-youtube"></i></a>
                    <a href=""><i class="fab fa-instagram"></i></a>
                </nav>
                <div class="info-evento">
                    <div class="clearfix">
                        <p class="fecha"><i class="far fa-calendar-alt"></i> 10-12 Dic</p>
                        <p class="ciudad"><i class="fas fa-map-marker-alt"></i> Cali, CO</p>
                    </div>
                    <h1 class="nombre-sitio">GdlWebCamp</h1>
                    <p class="slogan">La mejor conferencia de <span>diseño web</span></p>
                </div>
                <!--info-evento-->
            </div>
            <!--contenido-header-->
        </div>
        <!--hero-->
    </header>

    <div class="barra">
        <div class="contenedor clearfix">
            <div class="logo">
            <a href="index.php">
                <img src="img/logo.svg" alt="Logo gdlwebcamp">
            </a>
            </div>

            <!-- MENÚ HAMBURGUESA -->
            <div class="menu-movil">
                <span></span>
                <span></span>
                <span></span>
            </div>

            <nav class="navegacion-ppal clearfix">
                <a href="conferencia.php">Conferencia</a>
                <a href="calendario.php">Calendario</a>
                <a href="invitados.php">Invitados</a>
                <a href="registro.php">Reservaciones</a>
            </nav>
        </div>
        <!--contenedor-->
    </div>
    <!--barra-->
    <section class="seccion contenedor">
        <h2>La mejor conferencia de diseño web en español</h2>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Non maxime voluptate distinctio? Fugit voluptatem quas provident neque atque voluptatum. Itaque aliquid facilis quos temporibus eaque labore commodi dolore fugit fuga? Fugit voluptatem
            quas provident neque atque voluptatum. Itaque aliquid facilis quos temporibus eaque labore commodi dolore fugit fuga?</p>
    </section>

    <section class="programa">
        <div class="contenedor-video">
            <video autoplay loop poster="bg-talleres.jpg">
                <!-- El MP4 siempre debe ir de primero para que los dispositivos iOS no pongan problema -->
                <source src="video/video.mp4" type="video/mp4">
                <source src="video/video.webm" type="video/webm">
                <source src="video/video.ogv" type="video/ogg">
            </video>
        </div>
        <!--contenedor-video-->

        <div class="contenido-programa">
            <div class="contenedor">
                <div class="programa-evento">
                    <h2>Programa del evento</h2>

                    
                    <nav class="menu-programa">
                                                                                                            <!-- strtolower: convierte una cadena en minúsculas -->
                            <a href="#talleres"><i class="fas fa-code"></i> Talleres</a>
                            <!-- <pre>
                                                            </pre> -->
                                                                                                            <!-- strtolower: convierte una cadena en minúsculas -->
                            <a href="#conferencias"><i class="fas fa-comment"></i> Conferencias</a>
                            <!-- <pre>
                                                            </pre> -->
                                                                                                            <!-- strtolower: convierte una cadena en minúsculas -->
                            <a href="#seminario"><i class="fas fa-university"></i> Seminario</a>
                            <!-- <pre>
                                                            </pre> -->
                                            </nav>

                                                    <div id="talleres" class="info-curso ocultar clearfix">
                                                        
                                <div class="detalle-evento">
                                    <h3>Responsive Web Design</h3>
                                    <p><i class="far fa-clock"></i> 10:00:00</p>
                                    <p><i class="far fa-calendar-alt"></i> 2016-12-09</p>
                                    <p><i class="fas fa-user"></i> Rafael Bautista</p>
                                </div>
                                
                                                                                    
                                <div class="detalle-evento">
                                    <h3>Flexbox</h3>
                                    <p><i class="far fa-clock"></i> 12:00:00</p>
                                    <p><i class="far fa-calendar-alt"></i> 2016-12-09</p>
                                    <p><i class="fas fa-user"></i> Shari Herrera</p>
                                </div>
                                
                                                            <a href="calendario.php" class="boton float-right">Ver todos</a>
                                </div> <!-- talleres -->
                                                                                        <div id="conferencias" class="info-curso ocultar clearfix">
                                                        
                                <div class="detalle-evento">
                                    <h3>Como ser freelancer</h3>
                                    <p><i class="far fa-clock"></i> 10:00:00</p>
                                    <p><i class="far fa-calendar-alt"></i> 2016-12-09</p>
                                    <p><i class="fas fa-user"></i> Susan Sanchez</p>
                                </div>
                                
                                                                                    
                                <div class="detalle-evento">
                                    <h3>Tecnologías del Futuro</h3>
                                    <p><i class="far fa-clock"></i> 17:00:00</p>
                                    <p><i class="far fa-calendar-alt"></i> 2016-12-09</p>
                                    <p><i class="fas fa-user"></i> Rafael Bautista</p>
                                </div>
                                
                                                            <a href="calendario.php" class="boton float-right">Ver todos</a>
                                </div> <!-- talleres -->
                                                                                        <div id="seminario" class="info-curso ocultar clearfix">
                                                        
                                <div class="detalle-evento">
                                    <h3>Diseño UI y UX para móviles</h3>
                                    <p><i class="far fa-clock"></i> 10:00:00</p>
                                    <p><i class="far fa-calendar-alt"></i> 2016-12-09</p>
                                    <p><i class="fas fa-user"></i> Susan Sanchez</p>
                                </div>
                                
                                                                                    
                                <div class="detalle-evento">
                                    <h3>Aprende a Programar en una mañana</h3>
                                    <p><i class="far fa-clock"></i> 10:00:00</p>
                                    <p><i class="far fa-calendar-alt"></i> 2016-12-10</p>
                                    <p><i class="fas fa-user"></i> Gregorio Sanchez</p>
                                </div>
                                
                                                            <a href="calendario.php" class="boton float-right">Ver todos</a>
                                </div> <!-- talleres -->
                                                        
                    
                </div>
                <!--programa-evento-->
            </div>
            <!--contenedor-->
        </div>
        <!--contenido-programa-->
    </section>

    <!-- Sección de Invitados -->
    
<!-- Deben ir por fuera del WHILE -->
<section class="invitados contenedor seccion">
    <h2>Nuestros invitados</h2>
    <ul class="lista-invitados clearfix">

                        
            <li>
                <div class="invitado">
                    <a class="invitado-info" href="#invitado1">
                        <img src="img/invitados/invitado1.jpg" alt="Imagen invitado">
                        <p>Rafael Bautista</p>
                    </a>
                </div>
            </li>
            <div style="display:none;">
                <div class="invitado-info" id="invitado1">
                    <h2>Rafael Bautista</h2>
                    <img src="img/invitados/invitado1.jpg" alt="Imagen invitado">
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Non maxime voluptate distinctio? Fugit voluptatem quas provident neque atque voluptatum.</p>
                </div>
            </div>
                        
                            
            <li>
                <div class="invitado">
                    <a class="invitado-info" href="#invitado2">
                        <img src="img/invitados/invitado2.jpg" alt="Imagen invitado">
                        <p>Shari Herrera</p>
                    </a>
                </div>
            </li>
            <div style="display:none;">
                <div class="invitado-info" id="invitado2">
                    <h2>Shari Herrera</h2>
                    <img src="img/invitados/invitado2.jpg" alt="Imagen invitado">
                    <p>Itaque aliquid facilis quos temporibus eaque labore commodi dolore fugit fuga? Fugit voluptatem quas provident neque atque voluptatum. Itaque aliquid facilis.</p>
                </div>
            </div>
                        
                            
            <li>
                <div class="invitado">
                    <a class="invitado-info" href="#invitado3">
                        <img src="img/invitados/invitado3.jpg" alt="Imagen invitado">
                        <p>Gregorio Sanchez</p>
                    </a>
                </div>
            </li>
            <div style="display:none;">
                <div class="invitado-info" id="invitado3">
                    <h2>Gregorio Sanchez</h2>
                    <img src="img/invitados/invitado3.jpg" alt="Imagen invitado">
                    <p>Fugit voluptatem quas provident neque atque voluptatum. Itaque aliquid facilis quos temporibus eaque labore commodi dolore fugit fuga?</p>
                </div>
            </div>
                        
                            
            <li>
                <div class="invitado">
                    <a class="invitado-info" href="#invitado4">
                        <img src="img/invitados/invitado4.jpg" alt="Imagen invitado">
                        <p>Susana Rivera</p>
                    </a>
                </div>
            </li>
            <div style="display:none;">
                <div class="invitado-info" id="invitado4">
                    <h2>Susana Rivera</h2>
                    <img src="img/invitados/invitado4.jpg" alt="Imagen invitado">
                    <p>Non maxime voluptate distinctio? Fugit voluptatem quas provident neque atque voluptatum. Itaque aliquid facilis quos temporibus eaque labore commodi dolore.</p>
                </div>
            </div>
                        
                            
            <li>
                <div class="invitado">
                    <a class="invitado-info" href="#invitado5">
                        <img src="img/invitados/invitado5.jpg" alt="Imagen invitado">
                        <p>Harold Garcia</p>
                    </a>
                </div>
            </li>
            <div style="display:none;">
                <div class="invitado-info" id="invitado5">
                    <h2>Harold Garcia</h2>
                    <img src="img/invitados/invitado5.jpg" alt="Imagen invitado">
                    <p>Itaque aliquid facilis quos temporibus eaque labore commodi dolore fugit fuga? Non maxime voluptate distinctio? Fugit voluptatem quas.</p>
                </div>
            </div>
                        
                            
            <li>
                <div class="invitado">
                    <a class="invitado-info" href="#invitado6">
                        <img src="img/invitados/invitado6.jpg" alt="Imagen invitado">
                        <p>Susan Sanchez</p>
                    </a>
                </div>
            </li>
            <div style="display:none;">
                <div class="invitado-info" id="invitado6">
                    <h2>Susan Sanchez</h2>
                    <img src="img/invitados/invitado6.jpg" alt="Imagen invitado">
                    <p>Fugit voluptatem quas provident neque atque voluptatum. Itaque aliquid facilis quos temporibus eaque labore commodi dolore fugit fuga?</p>
                </div>
            </div>
                        
                
<!-- Deben ir por fuera del WHILE -->
    </ul>
</section>


    <!-- PARALLAX será para poner las propiedades del fondo y el efecto de la img estática -->
    <div class="contador parallax">
        <div class="contenedor">
            <ul class="resumen-evento clearfix">
                <!-- Los números de aquí se agregan con el plugin animateNumber de jQuery -->
                <li>
                    <p class="numero"></p>Invitados
                </li>
                <li>
                    <p class="numero"></p>Talleres
                </li>
                <li>
                    <p class="numero"></p>Días
                </li>
                <li>
                    <p class="numero"></p>Conferencias
                </li>
            </ul>
        </div>
    </div>

    <section class="precios seccion">
        <h2>Precios</h2>
        <div class="contenedor">
            <ul class="lista-precios clearfix">
                <li>
                    <div class="tabla-precio">
                        <h3>Pase por día</h3>
                        <p class="numero">$30</p>
                        <ul>
                            <li>Bocadillos gratis</li>
                            <li>Todas las conferencias</li>
                            <li>Todos los talleres</li>
                        </ul>
                        <a href="#" class="boton hollow">Comprar</a>
                    </div>
                    <!--tabla-precio-->
                </li>
                <li>
                    <div class="tabla-precio">
                        <h3>Todos los días</h3>
                        <p class="numero">$50</p>
                        <ul>
                            <li>Bocadillos gratis</li>
                            <li>Todas las conferencias</li>
                            <li>Todos los talleres</li>
                        </ul>
                        <a href="#" class="boton">Comprar</a>
                    </div>
                    <!--tabla-precio-->
                </li>
                <li>
                    <div class="tabla-precio">
                        <h3>Pase por 2 días</h3>
                        <p class="numero">$45</p>
                        <ul>
                            <li>Bocadillos gratis</li>
                            <li>Todas las conferencias</li>
                            <li>Todos los talleres</li>
                        </ul>
                        <a href="#" class="boton hollow">Comprar</a>
                    </div>
                    <!--tabla-precio-->
                </li>
            </ul>
        </div>
    </section>

    <div id="mapa" class="mapa">

    </div>

    <section class="seccion">
        <h2>Testimoniales</h2>
        <div class="testimoniales contenedor clearfix">
            <div class="testimonial">
                <blockquote>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam animi consequuntur esse tempora nemo culpa atque, corporis cum ipsam modi aliquam natus voluptatum temporibus.</p>
                    <footer class="info-testimonial clearfix">
                        <img src="img/testimonial.jpg" alt="Imagen testimonial">
                        <cite>Oswaldo Aponte Escobedo <span>Diseñador en @prisma</span></cite>
                    </footer>
                </blockquote>
            </div>
            <!--testimonial-->
            <div class="testimonial">
                <blockquote>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam animi consequuntur esse tempora nemo culpa atque, corporis cum ipsam modi aliquam natus voluptatum temporibus.</p>
                    <footer class="info-testimonial clearfix">
                        <img src="img/testimonial.jpg" alt="Imagen testimonial">
                        <cite>Oswaldo Aponte Escobedo <span>Diseñador en @prisma</span></cite>
                    </footer>
                </blockquote>
            </div>
            <!--testimonial-->
            <div class="testimonial">
                <blockquote>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam animi consequuntur esse tempora nemo culpa atque, corporis cum ipsam modi aliquam natus voluptatum temporibus.</p>
                    <footer class="info-testimonial clearfix">
                        <img src="img/testimonial.jpg" alt="Imagen testimonial">
                        <cite>Oswaldo Aponte Escobedo <span>Diseñador en @prisma</span></cite>
                    </footer>
                </blockquote>
            </div>
            <!--testimonial-->
        </div>
    </section>

    <div class="newsletter parallax">
        <div class="contenido contenedor">
            <p>Regístrate en newsletter:</p>
            <h3>gdlwebcamp</h3>
            <a href="#mc_embed_signup" class="btn_newsletter boton transparente">Registro</a>
        </div>
    </div>

    <section class="seccion">
        <h2>Faltan</h2>
        <div class="cuenta-regresiva contenedor">
            <ul class="clearfix">
                <li>
                    <p id="dias" class="numero"></p>días
                </li>
                <li>
                    <p id="horas" class="numero"></p>horas
                </li>
                <li>
                    <p id="minutos" class="numero"></p>minutos
                </li>
                <li>
                    <p id="segundos" class="numero"></p>segundos
                </li>
            </ul>
        </div>
    </section>

<!-- AQUÍ SE LINKEA AL ARCHIVO QUE CONTIENE EL FOOTER DE LA PÁGINA WEB -->
<footer class="site-footer">
        <div class="contenedor clearfix contenido">
            <div class="footer-info">
                <h3>Sobre <span>gdlwebcamp</span></h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt cupiditate quo commodi possimus magnam? Harum aut, temporibus consectetur accusamus ullam vitae laboriosam nisi, quisquam voluptate esse pariatur animi nobis assumenda.</p>
            </div>
            <div class="ultimos-tweets">
                <h3>Últimos <span>tweets</span></h3>
                <ul>
                    <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt cupiditate quo commodi possimus magnam?</li>
                    <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt cupiditate quo commodi possimus magnam?</li>
                    <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt cupiditate quo commodi possimus magnam?</li>
                </ul>
            </div>
            <div class="menu">
                <h3>Redes <span>sociales</span></h3>
                <nav class="redes-sociales">
                    <a href=""><i class="fab fa-facebook-f"></i></a>
                    <a href=""><i class="fab fa-twitter"></i></a>
                    <a href=""><i class="fab fa-pinterest-p"></i></a>
                    <a href=""><i class="fab fa-youtube"></i></a>
                    <a href=""><i class="fab fa-instagram"></i></a>
                </nav>
            </div>
        </div>
        <!--contenido-->

        <p class="copyright">
            Todos los derechos reservados GDLWEBCAMP 2016.
        </p>

        <!-- Begin Mailchimp Signup Form -->
        <link href="//cdn-images.mailchimp.com/embedcode/classic-10_7.css" rel="stylesheet" type="text/css">
        <style type="text/css">
            #mc_embed_signup{background:#fff; clear:left; font:14px Helvetica,Arial,sans-serif; }
            /* Add your own Mailchimp form style overrides in your site stylesheet or in this style block.
            We recommend moving this block and the preceding CSS link to the HEAD of your HTML file. */
        </style>

        <div style="display: none;">
            <div id="mc_embed_signup">
                <form action="https://hotmail.us10.list-manage.com/subscribe/post?u=5844d22a555e9c4b7a4fd8bec&amp;id=58441eda51" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
                    <div id="mc_embed_signup_scroll">
                    <h2>Suscríbete al Newsletter y no te pierdas nada de este evento</h2>
                <div class="indicates-required"><span class="asterisk">*</span> indica los campos obligatorios</div>
                <div class="mc-field-group">
                    <label for="mce-EMAIL">Correo electrónico  <span class="asterisk">*</span>
                </label>
                    <input type="email" value="" name="EMAIL" class="required email" id="mce-EMAIL">
                </div>
                <div class="mc-field-group">
                    <label for="mce-FNAME">Primer nombre  <span class="asterisk">*</span>
                </label>
                    <input type="text" value="" name="FNAME" class="required" id="mce-FNAME">
                </div>
                <div class="mc-field-group">
                    <label for="mce-LNAME">Primer apellido  <span class="asterisk">*</span>
                </label>
                    <input type="text" value="" name="LNAME" class="required" id="mce-LNAME">
                </div>
                    <div id="mce-responses" class="clear">
                        <div class="response" id="mce-error-response" style="display:none"></div>
                        <div class="response" id="mce-success-response" style="display:none"></div>
                    </div>    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                    <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_5844d22a555e9c4b7a4fd8bec_58441eda51" tabindex="-1" value=""></div>
                    <div class="clear"><input type="submit" value="Suscribirse" name="subscribe" id="mc-embedded-subscribe" class="boton btn_suscribirse"></div>
                    </div>
                </form>
            </div>
            <script type='text/javascript' src='//s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js'></script><script type='text/javascript'>(function($) {window.fnames = new Array(); window.ftypes = new Array();fnames[0]='EMAIL';ftypes[0]='email';fnames[1]='FNAME';ftypes[1]='text';fnames[2]='LNAME';ftypes[2]='text';fnames[3]='ADDRESS';ftypes[3]='address';fnames[4]='PHONE';ftypes[4]='phone';fnames[5]='BIRTHDAY';ftypes[5]='birthday'; /*
            * Translated default messages for the $ validation plugin.
            * Locale: ES
            */
            $.extend($.validator.messages, {
            required: "Este campo es obligatorio.",
            remote: "Por favor, rellena este campo.",
            email: "Por favor, escribe una dirección de correo válida",
            url: "Por favor, escribe una URL válida.",
            date: "Por favor, escribe una fecha válida.",
            dateISO: "Por favor, escribe una fecha (ISO) válida.",
            number: "Por favor, escribe un número entero válido.",
            digits: "Por favor, escribe sólo dígitos.",
            creditcard: "Por favor, escribe un número de tarjeta válido.",
            equalTo: "Por favor, escribe el mismo valor de nuevo.",
            accept: "Por favor, escribe un valor con una extensión aceptada.",
            maxlength: $.validator.format("Por favor, no escribas más de {0} caracteres."),
            minlength: $.validator.format("Por favor, no escribas menos de {0} caracteres."),
            rangelength: $.validator.format("Por favor, escribe un valor entre {0} y {1} caracteres."),
            range: $.validator.format("Por favor, escribe un valor entre {0} y {1}."),
            max: $.validator.format("Por favor, escribe un valor menor o igual a {0}."),
            min: $.validator.format("Por favor, escribe un valor mayor o igual a {0}.")
            });}(jQuery));var $mcj = jQuery.noConflict(true);</script>
            <!--End mc_embed_signup-->
        </div>

    </footer>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" integrity="sha512-3n19xznO0ubPpSwYCRRBgHh63DrV+bdZfHK52b1esvId4GsfwStQNPJFjeQos2h3JwCmZl0/LgLxSKMAI55hgw==" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script>
        window.jQuery || document.write('<script src="js/vendor/jquery-3.4.1.min.js"><\/script>')
    </script>
    <script src="js/plugins.js"></script>
    <!-- Link al plugin para animar los números -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-animateNumber/0.0.14/jquery.animateNumber.min.js" integrity="sha512-WY7Piz2TwYjkLlgxw9DONwf5ixUOBnL3Go+FSdqRxhKlOqx9F+ee/JsablX84YBPLQzUPJsZvV88s8YOJ4S/UA==" crossorigin="anonymous"></script>
    <!-- Link al plugin para cuenta regresiva -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.countdown/2.2.0/jquery.countdown.min.js" integrity="sha512-lteuRD+aUENrZPTXWFRPTBcDDxIGWe5uu0apPEn+3ZKYDwDaEErIK9rvR0QzUGmUQ55KFE2RqGTVoZsKctGMVw==" crossorigin="anonymous"></script>
    <!-- Link al plugin para cambiar estilos al header principal -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lettering.js/0.7.0/jquery.lettering.min.js" integrity="sha512-9ex1Kp3S7uKHVZmQ44o5qPV6PnP8/kYp8IpUHLDJ+GZ/qpKAqGgEEH7rhYlM4pTOSs/WyHtPubN2UePKTnTSww==" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.colorbox/1.6.4/jquery.colorbox-min.js" integrity="sha512-DAVSi/Ovew9ZRpBgHs6hJ+EMdj1fVKE+csL7mdf9v7tMbzM1i4c/jAvHE8AhcKYazlFl7M8guWuO3lDNzIA48A==" crossorigin="anonymous"></script>    
    <!-- Link al script de leaflet para el mapa -->
    <script src="https://unpkg.com/leaflet@1.6.0/dist/leaflet.js"></script>
    <script src="js/main.js"></script>
    <script src="js/cotizador.js"></script>

    <!-- Google Analytics: change UA-XXXXX-Y to be your site's ID. -->
    <script>
        window.ga = function() {
            ga.q.push(arguments)
        };
        ga.q = [];
        ga.l = +new Date;
        ga('create', 'UA-XXXXX-Y', 'auto');
        ga('set', 'transport', 'beacon');
        ga('send', 'pageview')
    </script>
    <script src="https://www.google-analytics.com/analytics.js" async></script>
    