<?php
    $id = $_GET['id'];

    if(!filter_var($id, FILTER_VALIDATE_INT)) {
        die("Error");
    }
  include_once 'funciones/sesiones.php';
  //Para que se conecte a la base de datos
  include_once 'funciones/funciones.php';
  include_once 'templates/header.php';
  include_once 'templates/barra.php';
  include_once 'templates/navegacion.php';
?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Editar invitados</h1>
            <small>Llena el formulario para editar un invitado</small>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <div class="row">
      <div class="col-md-8">

        <!-- Main content -->
        <section class="content">

          <!-- Default box -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Editar invitado</h3>
            </div>
            <div class="card-body">
            <?php
                $sql = "SELECT * FROM invitados WHERE invitado_id = $id";
                $resultado = $conn->query($sql);
                $invitado = $resultado->fetch_assoc();

                // echo "<pre>";
                // var_dump($invitado);
                // echo "</pre>";
            ?>
                <!-- Cuando se trabaja con archivos/imágenes, se añade el atributo enctype -->
            <form role="form" name="guardar-registro" id="guardar-registro-archivo" method="post" action="modelo-invitado.php" enctype="multipart/form-data">
                    <div class="card-body">
                      <div class="form-group">
                        <label for="nombre-invitado">Nombre:</label>
                        <!-- El NAME en los formularios sirve para leer su información en JS -->
                        <input type="text" value="<?php echo $invitado['nombre_invitado']; ?>" class="form-control" id="nombre-invitado" name="nombre-invitado" placeholder="Ingresa el nombre del invitado">
                      </div>

                      <div class="form-group">
                        <label for="apellido-invitado">Apellido:</label>
                        <!-- El NAME en los formularios sirve para leer su información en JS -->
                        <input type="text" value="<?php echo $invitado['apellido_invitado']; ?>" class="form-control" id="apellido-invitado" name="apellido-invitado" placeholder="Ingresa el apellido del invitado">
                      </div>

                      <div class="form-group">
                          <label for="biografia_invitado">Biografía:</label>
                          <textarea class="form-control" name="biografia-invitado" id="biografia_invitado" rows="5" placeholder="Biografía del invitado"><?php echo $invitado['descripcion']; ?></textarea>
                      </div>

                      <div class="form-group">
                          <label for="imagen_actual">Imagen actual:</label>
                          <br>
                          <img src="../img/invitados/<?php echo $invitado['url_imagen']; ?>" width="200">
                      </div>

                        <div class="form-group">
                            <label for="imagen_invitado">Imagen nueva:</label>
                            <div class="input-group">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="imagen_invitado" name="archivo_imagen">
                                    <label class="custom-file-label" for="imagen_invitado">Añada la imagen del invitado aquí</label>
                                </div>
                            </div>
                        </div>
                      
                    </div>
                    <!-- /.card-body -->

                    <div class="card-footer">
                      <input type="hidden" name="registro" value="actualizar">
                      <input type="hidden" name="id_registro" value="<?php echo $invitado['invitado_id']; ?>">
                      <button type="submit" class="btn btn-primary" id="crear_registro">Añadir</button>
                    </div>
                  </form>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->

        </section>
        <!-- /.content -->

      </div>
    </div>
    <!-- /.row -->
    
  </div>
  <!-- /.content-wrapper -->

<?php include_once 'templates/footer.php'; ?>


