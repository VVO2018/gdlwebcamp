<?php
    //No me dejaba entrar al login de la nada, y al poner esto, se resolvió.
    error_reporting(E_ALL ^ E_NOTICE);

    //Para que se conecte a la base de datos
    include_once 'funciones/funciones.php';

    //Ping revisa que se haga conexión a la BD
    // if($conn->ping()) {
    //     echo "Conectado";
    // } else {
    //     echo "No";
    // }

    $usuario = $_POST['usuario'];
    $nombre = $_POST['nombre'];
    $password = $_POST['password'];
    $id_registro = $_POST['id_registro'];

    //Cuando se quiera añadir un admin. Se usa el input hidden como referencia para saber que se insertó info.
    if($_POST['registro'] == 'nuevo'){
        //DIE hace que deje de ejecutarse el código posterior a su llamado
        // die(json_encode($_POST));

        $opciones = array(
            //el default es 10: es la cantidad de iteraciones para generar el password hasheado
            'cost' => 12
        );

        //Encriptar contraseñas. Al hashear una contraseña siempre nos resultará una cadena de 60 caracteres.
        $password_hashed = password_hash($password, PASSWORD_BCRYPT, $opciones);

        // echo $password_hashed;

        try {
            $stmt = $conn->prepare("INSERT INTO admins (usuario, nombre, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $usuario, $nombre, $password_hashed);
            $stmt->execute();
            $id_registro = $stmt->insert_id;
            //Si no hay registro, el id será igual a cero
            if($id_registro > 0) {
                $respuesta = array(
                    'respuesta' => 'exito',
                    // 'id_admin' => $stmt
                    'id_admin' => $id_registro
                );
            } else {
                $respuesta = array(
                    'respuesta' => 'error'
                );
            }
            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            echo "Error: " . $e->getMessage();
        }

        die(json_encode($respuesta));
    }

    //Cuando se quiere editar un usuario
    if($_POST['registro'] == 'actualizar') {
        // die(json_encode($_POST));

        try {
            //Si la contraseña se deja vacía, esta no se debe actualizar. Debe conservar su valor anterior.
            if(empty($_POST['password'])) {
                //NOW() es una función de MySQL que toma la hora actual del servidor en el que se encuentre
                $stmt = $conn->prepare("UPDATE admins SET usuario = ?, nombre = ?, editado = NOW() WHERE id_admin = ?");
                $stmt->bind_param("ssi", $usuario, $nombre, $id_registro);
            } else {
                $opciones = array(
                    'cost' => 12
                );
    
                $hash_password = password_hash($password, PASSWORD_BCRYPT, $opciones);
                $stmt = $conn->prepare("UPDATE admins SET usuario = ?, nombre = ?, password = ?, editado = NOW() WHERE id_admin = ?");
                $stmt->bind_param("sssi", $usuario, $nombre, $hash_password, $id_registro);
            }

            $stmt->execute();
            // if($id_registro > 0)
            if($stmt->affected_rows) {
                $respuesta = array(
                    'respuesta' => 'exito',
                    'id_actualizado' => $stmt->insert_id
                );
            } else {
                $respuesta = array(
                    'respuesta' => 'error'
                );
            }
            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            $respuesta = array(
                'respuesta' => $e->getMessage()
            );
        }

        die(json_encode($respuesta));
    }

    //Eliminar un administrador
    if($_POST['registro'] == 'eliminar') {
        // die(json_encode($_POST));

        $id_borrar = $_POST['id'];

        try {
            $stmt = $conn->prepare('DELETE FROM admins WHERE id_admin = ?');
            $stmt->bind_param('i', $id_borrar);
            $stmt->execute();
            if($stmt->affected_rows) {
                $respuesta = array(
                    'respuesta' => 'exito',
                    'id_eliminado' => $id_borrar
                );
            } else {
                $respuesta = array(
                    'respuesta' => 'error'
                );
            }
            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            $respuesta = array(
                'respuesta' => $e->getMessage()
            );
        }
        die(json_encode($respuesta));
    }

    
?>