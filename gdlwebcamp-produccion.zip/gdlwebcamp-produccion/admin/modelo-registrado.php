<?php
    //No me dejaba entrar al login de la nada, y al poner esto, se resolvió.
    error_reporting(E_ALL ^ E_NOTICE);

    //Para que se conecte a la base de datos
    include_once 'funciones/funciones.php';

    //Ping revisa que se haga conexión a la BD
    // if($conn->ping()) {
    //     echo "Conectado";
    // } else {
    //     echo "No";
    // }

    //Eliminar un usuario registrado
    if($_POST['registro'] == 'eliminar') {
        // die(json_encode($_POST));

        $id_borrar = $_POST['id'];

        try {
            $stmt = $conn->prepare('DELETE FROM registrados WHERE id_registrado = ?');
            $stmt->bind_param('i', $id_borrar);
            $stmt->execute();
            if($stmt->affected_rows) {
                $respuesta = array(
                    'respuesta' => 'exito',
                    'id_eliminado' => $id_borrar
                );
            } else {
                $respuesta = array(
                    'respuesta' => 'error'
                );
            }
            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            $respuesta = array(
                'respuesta' => $e->getMessage()
            );
        }
        die(json_encode($respuesta));
    }


    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $email = $_POST['email'];

    //Boletos
    $boletos_adquiridos = $_POST['boletos'];
    //Camisas y etiquetas
    $camisas = $_POST['pedido_extra']['camisas']['cantidad'];
    $etiquetas = $_POST['pedido_extra']['etiquetas']['cantidad'];

    $pedido = productos_json($boletos_adquiridos, $camisas, $etiquetas);

    $total = $_POST['total_pedido'];
    $regalo = $_POST['regalo'];

    $eventos = $_POST['registro_evento'];
    $registro_eventos = eventos_json($eventos);

    $fecha_registro = $_POST['fecha_registro'];
    $id_registro = $_POST['id_registro'];

    //Cuando se quiera registrar un usuario. Se usa el input hidden como referencia para saber que se insertó info.
    if($_POST['registro'] == 'nuevo'){
        // die(json_encode($_POST));
        // $respuesta = array(
        //     'boletos' => $pedido
        // );
        // die(json_encode($respuesta));

        try {
            $stmt = $conn->prepare('INSERT INTO registrados (nombre_registrado, apellido_registrado, email_registrado, fecha_registro, pases_articulos, talleres_registrados, regalo, total_pagado, pagado) VALUES (?, ?, ?, NOW(), ?, ?, ?, ?, 1)');
            $stmt->bind_param('sssssis', $nombre, $apellido, $email, $pedido, $registro_eventos, $regalo, $total);
            $stmt->execute();
            $id_insertado = $stmt->insert_id;
            if($stmt->affected_rows) {
                $respuesta = array(
                    'respuesta' => 'exito',
                    'id_insertado' => $id_insertado
                );
            } else {
                $respuesta = array(
                    'respuesta' => 'error'
                );
            }
            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            $respuesta = array(
                'respuesta' => $e->getMessage()
            );
        }
        die(json_encode($respuesta));
    }

    //Cuando se quiere editar un usuario registrado
    if($_POST['registro'] == 'actualizar') {
        // die(json_encode($_POST));

        try {
            $stmt = $conn->prepare("UPDATE registrados SET nombre_registrado = ?, apellido_registrado = ?, email_registrado = ?, fecha_registro = ?, pases_articulos = ?, talleres_registrados = ?, regalo = ?, total_pagado = ?, pagado = 1 WHERE id_registrado = ?");
            $stmt->bind_param("ssssssisi", $nombre, $apellido, $email, $fecha_registro, $pedido, $registro_eventos, $regalo, $total, $id_registro);
            $stmt->execute();
            // if($id_registro > 0)
            if($stmt->affected_rows) {
                $respuesta = array(
                    'respuesta' => 'exito',
                    'id_actualizado' => $id_registro
                );
            } else {
                $respuesta = array(
                    'respuesta' => 'error'
                );
            }
            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            $respuesta = array(
                'respuesta' => $e->getMessage()
            );
        }

        die(json_encode($respuesta));
    }

    
    
?>