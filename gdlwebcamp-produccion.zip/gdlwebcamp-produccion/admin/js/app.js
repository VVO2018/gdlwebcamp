$(document).ready(function() {
    $("#registros").DataTable({
        "responsive": true,
        "autoWidth": false,
        "paging": true,
        "pageLength": 10,
        "lengthChange": false,
        "searching": true,
        "ordering": true,
        "info": true,
        "language": {
            paginate: {
                next: 'Siguiente',
                previous: 'Anterior',
                last: 'Último',
                first: 'Primero'
            },
            info: 'Mostrando _START_ a _END_ de _TOTAL_ resultados',
            emptyTable: 'No hay registros',
            infoEmpty: '0 registros',
            search: 'Buscar:'
        }
    });
    // $('#example2').DataTable({
    //     "paging": true,
    //     "pageLength": 10,
    //     "lengthChange": false,
    //     "searching": false,
    //     "ordering": true,
    //     "info": true,
    //     "autoWidth": false,
    //     "responsive": true,
    //     "language": {
    //         paginate: {
    //             next: 'Siguiente',
    //             previous: 'Anterior'
    //         }
    //     }
    // });


    //---------------------FUNCIONES DE LA PÁGINA DE ADMINS------------------------------

    $('#crear_registro_admin').attr('disabled', true);


    //En vez de 'blur' puedo usar 'input' para que haga la validación a medida que escribo
    $('#repetir_password').on('blur', function() {
        var password_nuevo = $('#password').val();

        if ($(this).val() === password_nuevo) {
            $('#resultado_password').text('Correcto');
            $('#resultado_password').addClass('valid-feedback').removeClass('invalid-feedback');
            $('input#password').addClass('is-valid').removeClass('is-invalid');
            $('input#repetir_password').addClass('is-valid').removeClass('is-invalid');
            $('#crear_registro').attr('disabled', false);
        } else {
            $('#resultado_password').text('Las contraseñas no son iguales');
            $('#resultado_password').addClass('invalid-feedback').removeClass('valid-feedback');;
            $('input#password').addClass('is-invalid').removeClass('is-valid');;
            $('input#repetir_password').addClass('is-invalid').removeClass('is-valid');;
        }
    });

    //--------------------FECHA Y HORA-----------------

    //Categoria Selección
    //Initialize Select2 Elements
    $('.select2').select2();

    //Fecha Evento
    //Date range picker
    $('#reservationdate').datetimepicker({
        format: 'L'
    });

    //Hora
    //Timepicker
    $('#timepicker').datetimepicker({
        format: 'LT'
    })

    //--------------------ICON PICKER----------------------

    //Iconos
    $('#icono').iconpicker();
    // $("div.iconpicker-popover").removeClass('fade');

    bsCustomFileInput.init();

    //---------------------LINE CHART------------------------

    //función de Jquery para leer json
    $.getJSON('servicio-registrados.php', function(data) {
        // console.log(data);
        var line = new Morris.Line({
            element: 'line-chart',
            resize: true,
            data: data,
            xkey: 'fecha',
            ykeys: ['cantidad'],
            labels: ['Item 1'],
            lineColors: ['#3c8dbc'],
            hideHover: 'auto'
        });
    });

});