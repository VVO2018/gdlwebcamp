$(document).ready(function() {
    //Cuando me loguee como admin
    $('#login-admin').on('submit', function(e) {
        e.preventDefault();

        //serializeArray crea objetos (llave - valor) con los datos dados en el form
        var datos = $(this).serializeArray();

        // console.log(datos);

        //AJAX en JQuery
        $.ajax({
            //Se define el tipo de request (POST o GET)
            type: $(this).attr('method'),
            //Los datos que se van a enviar
            data: datos,
            //A dónde se van a enviar (el ACTION del formulario)
            url: $(this).attr('action'),
            dataType: 'json',
            //cuando la respuesta sea exitosa
            success: function(data) {
                //console.log(data);
                var resultado = data;
                if (resultado.respuesta === 'exitoso') {
                    Swal.fire(
                            'Login correcto',
                            '¡Bienvenido(a) ' + resultado.nombre + '!',
                            'success'
                        )
                        .then(resultado => {
                            if (resultado.value) {
                                window.location.href = 'admin-area.php';
                            }
                        })
                    setTimeout(function() {
                        window.location.href = 'admin-area.php';
                    }, 2000);
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: '¡Error!',
                        text: 'Usuario o contraseña incorrectos'
                    })
                }

            }
        })
    });
});