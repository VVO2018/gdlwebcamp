//JQuery
$(document).ready(function() {
    //Cuando se agregue un admin o cuando se edite
    $('#guardar-registro').on('submit', function(e) {
        e.preventDefault();

        //serializeArray crea objetos (llave - valor) con los datos dados en el form
        var datos = $(this).serializeArray();

        // console.log(datos);

        //AJAX en JQuery
        $.ajax({
            //Se define el tipo de request (POST o GET)
            type: $(this).attr('method'),
            //Los datos que se van a enviar
            data: datos,
            //A dónde se van a enviar (el ACTION del formulario)
            url: $(this).attr('action'),
            dataType: 'json',
            //cuando la respuesta sea exitosa
            success: function(data) {
                console.log(data);
                var resultado = data;
                if (resultado.respuesta === 'exito') {
                    Swal.fire(
                        'Correcto',
                        'El registro se guardó correctamente',
                        'success'
                    )
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: '¡Error!',
                        text: 'Algo salió mal'
                    })
                }
            }
        })
    });

    //Se ejecuta cuando hay un archivo/imagen
    $('#guardar-registro-archivo').on('submit', function(e) {
        e.preventDefault();

        //serializeArray sirve para datos, pero FormData trabaja con archivos e imágenes
        var datos = new FormData(this);

        // console.log(datos);

        //AJAX en JQuery
        $.ajax({
            //Se define el tipo de request (POST o GET)
            type: $(this).attr('method'),
            //Los datos que se van a enviar
            data: datos,
            //A dónde se van a enviar (el ACTION del formulario)
            url: $(this).attr('action'),
            dataType: 'json',
            //Las sigtes. líneas es cuando se trabaja con archivos
            contentType: false,
            processData: false,
            async: true,
            cache: false,
            //cuando la respuesta sea exitosa
            success: function(data) {
                console.log(data);
                var resultado = data;
                if (resultado.respuesta === 'exito') {
                    Swal.fire(
                        'Correcto',
                        'El registro se guardó correctamente',
                        'success'
                    )
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: '¡Error!',
                        text: 'Algo salió mal'
                    })
                }
            }
        })
    });

    //Eliminar un admin
    $('.borrar-registro').on('click', function(e) {
        e.preventDefault();

        var id = $(this).attr('data-id');
        var tipo = $(this).attr('data-tipo');

        // console.log('ID: ' + id);

        Swal.fire({
            title: '¿Estás seguro(a)?',
            text: "Un registro eliminado no se puede recuperar",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.value) {

                //AJAX puede mandar datos así no sea de un formulario
                $.ajax({
                    type: 'post',
                    data: {
                        'id': id,
                        'registro': 'eliminar'
                    },
                    url: 'modelo-' + tipo + '.php',
                    success: function(data) {
                        var resultado = JSON.parse(data);
                        // console.log(resultado);

                        if (resultado.respuesta == 'exito') {
                            Swal.fire(
                                'Eliminado',
                                'Registro eliminado con éxito',
                                'success'
                            )
                            jQuery('[data-id="' + resultado.id_eliminado + '"]').parents('tr').remove();
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: '¡Error!',
                                text: 'No se pudo eliminar'
                            })
                        }

                    }
                })

            }
        })

    });

});