<?php
    //No me dejaba entrar al login de la nada, y al poner esto, se resolvió.
    error_reporting(E_ALL ^ E_NOTICE);

    //Cuando me quiera loguear como admin. Se usa el input hidden como referencia para saber que se insertó info.
    if (isset($_POST['login-admin'])) {
        // die(json_encode($_POST));

        $usuario = $_POST['usuario'];
        $password = $_POST['password'];

        try {
            include_once 'funciones/funciones.php';
            $stmt = $conn->prepare("SELECT * FROM admins WHERE usuario = ?");
            $stmt->bind_param("s", $usuario);
            $stmt->execute();
            //bind_result se usa cuando se realiza una consulta a la BD y trae un valor de vuelta para usarlo posteriormente
            //se crean variables para cada campo que hayamos seleccionado de la base de datos
            $stmt->bind_result($id_admin, $usuario_admin, $nombre_admin, $password_admin, $editado, $nivel);
            if($stmt->affected_rows) {
                // die(json_encode($stmt->affected_rows));
                //El fetch imprime los resultados obtenidos
                $existe = $stmt->fetch();
                if($existe) {
                    //se compara la contraseña escrita con la que se trae de la BD
                    if(password_verify($password, $password_admin)) {
                        //Así se inicia una sesión en PHP luego de que ya te has logueado
                        session_start();
                        //Cuando el usuario se loguea, grabamos la sesión en el usuario y en el nombre
                        $_SESSION['usuario'] = $usuario_admin;
                        $_SESSION['nombre'] = $nombre_admin;
                        $_SESSION['nivel'] = $nivel;
                        $_SESSION['id'] = $id_admin;
                        
                        $respuesta = array(
                            'respuesta' => 'exitoso',
                            'nombre' => $nombre_admin
                        );
                    } else {
                        $respuesta = array(
                            'respuesta' => 'error'
                        );
                    }
                } else {
                    $respuesta = array(
                        'respuesta' => 'error'
                    );
                }
            }
            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            echo "Error: " . $e->getMessage();
        }

        die(json_encode($respuesta));
    }
?>