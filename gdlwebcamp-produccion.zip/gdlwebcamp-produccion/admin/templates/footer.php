<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.5
    </div>
    <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong> All rights
    reserved.
</footer>

</div>
<!-- ./wrapper -->

<!-- Link para que funcione fontawesome -->
<script src="https://kit.fontawesome.com/9413861877.js" crossorigin="anonymous"></script>
<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="js/bootstrap.bundle.min.js"></script>
<!-- DataTables de AdminLTE -->
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap4.min.js"></script>
<script src="js/dataTables.responsive.min.js"></script>
<script src="js/responsive.bootstrap4.min.js"></script>
<!-- AdminLTE App -->
<script src="js/adminlte.min.js"></script>
<!-- SweetAlert2 -->
<script src="js/sweetalert2.min.js"></script>
<script src="js/admin-ajax.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<!-- AdminLTE for demo purposes -->
<script src="js/demo.js"></script>
<script src="js/login-ajax.js"></script>
<script src="js/app.js"></script>
<!-- Categoria Evento -->
<!-- Select2 -->
<script src="js/select2.full.min.js"></script>
<!-- Fecha Evento -->
<!-- InputMask -->
<script src="js/moment.min.js"></script>
<script src="js/jquery.inputmask.bundle.min.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="js/tempusdominus-bootstrap-4.min.js"></script>
<script src="js/fontawesome-iconpicker.min.js"></script>
<script src="js/bs-custom-file-input.min.js"></script>
<script src="../js/cotizador.js"></script>
<script src="js/raphael.min.js"></script>
<script src="js/morris.min.js"></script>

</body>
</html>