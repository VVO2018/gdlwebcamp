<?php
  error_reporting(E_ALL ^ E_NOTICE);
  //Esta de SESIONES debe ir antes de TODO lo demás porque tiene una redirección
  include_once 'funciones/sesiones.php';
  include_once 'funciones/funciones.php';
  include_once 'templates/header.php';
  include_once 'templates/barra.php';
  include_once 'templates/navegacion.php';
?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Listado de personas registradas</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Maneja los visitantes registrados</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive">
                <table id="registros" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Fecha del registro</th>
                    <th>Artículos</th>
                    <th>Talleres</th>
                    <th>Regalo</th>
                    <th>Compra</th>
                    <th>Acciones</th>
                  </tr>
                  </thead>
                  <tbody>
                      <?php
                          try {
                            $sql = "SELECT registrados.*, regalos.nombre_regalo FROM registrados ";
                            $sql .= " JOIN regalos ";
                            $sql .= " ON registrados.regalo = regalos.id_regalo ";
                            $resultado = $conn->query($sql);
                            // echo $sql;
                          } catch (Exception $e) {
                            $error = $e->getMessage();
                            echo $error;
                          }
                          while($registrado = $resultado->fetch_assoc()) { ?>
                          <!-- <pre><?php //var_dump($registrados); ?></pre> -->

                            <tr>
                                <td>
                                  <?php
                                    echo $registrado['nombre_registrado'] . " " . $registrado['apellido_registrado'];
                                    echo "<br>";
                                    $pagado = $registrado['pagado'];
                                    if($pagado) {
                                        echo '<span class="badge bg-green">Ya pagó</span>';
                                    } else {
                                        echo '<span class="badge bg-red">No ha pagado</span>';
                                    }
                                    ?>
                                </td>
                                <td><?php echo $registrado['email_registrado']; ?></td>
                                <td><?php echo $registrado['fecha_registro']; ?></td>
                                <td>
                                  <?php
                                  //json_decode convierte un json a objeto. Con TRUE, hacemos que lo pase a arreglo.
                                    $articulos = json_decode($registrado['pases_articulos'], true);
                                    
                                    $arreglo_articulos = array(
                                        'un_dia' => 'Pase 1 día',
                                        'pase_2dias' => 'Pase 2 días',
                                        'pase_completo' => 'Pase completo',
                                        'camisas' => 'Camisas',
                                        'etiquetas' => 'Etiquetas'
                                    );

                                    foreach($articulos as $llave => $articulo) {
                                      // echo "<pre>";
                                      // var_dump($articulo);
                                      // echo "</pre>";
                                      //Mira que la llave 'cantidad' exista en el arreglo $articulo
                                      if(is_array($articulo) && array_key_exists('cantidad', $articulo)) {
                                        echo '<span class="badge badge-info right">' . $articulo['cantidad'] . '</span>' . " " . $arreglo_articulos[$llave] . "<br>";
                                      } else {
                                        echo '<span class="badge badge-info right">' . $articulo . '</span>' . " " . $arreglo_articulos[$llave] . "<br>";
                                      }
                                        
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php
                                        $talleres = json_decode($registrado['talleres_registrados'], true);
                                        //IMPLODE: todos los valores de un arreglo (sin las llaves) los coloca en una cadena
                                        $talleres = implode("', '", $talleres['eventos']);
                                        $sql_talleres = "SELECT nombre_evento, fecha_evento, hora_evento FROM eventos WHERE clave IN ('$talleres') OR evento_id IN ('$talleres')";
                                        // echo $sql_talleres;
                                        // var_dump($talleres);
                                        
                                        $resultado_talleres = $conn->query($sql_talleres);
                                        while($eventos = $resultado_talleres->fetch_assoc()) {
                                            $hora = $eventos['hora_evento'];
                                            $hora_formateada = date('h:i A', strtotime($hora));
                                            $fecha = $eventos['fecha_evento'];
                                            $fecha_formateada = date('m/d/Y', strtotime($fecha));
                                            echo $eventos['nombre_evento'] . " " . '<span class="color-info badge badge-light">' . $fecha_formateada . " " . $hora_formateada . '</span>' . "<br>";
                                        }
                                    ?>
                                </td>
                                <td><?php echo $registrado['nombre_regalo']; ?></td>
                                <td>$ <?php echo (float) $registrado['total_pagado']; ?></td>
                                <td>
                                    <a href="editar-registrado.php?id=<?php echo $registrado['id_registrado']; ?>" class="btn bg-orange btn-flat margin">
                                    <i class="fa fa-pencil"></i>
                                    </a>
                                    <a href="#" data-id="<?php echo $registrado['id_registrado']; ?>" data-tipo="registrado" class="btn bg-maroon btn-flat margin borrar-registro">
                                    <i class="fa fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                          <?php } ?>
                  </tbody>
                  <tfoot>
                  <tr>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Fecha del registro</th>
                    <th>Artículos</th>
                    <th>Talleres</th>
                    <th>Regalo</th>
                    <th>Compra</th>
                    <th>Acciones</th>
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php include_once 'templates/footer.php'; ?>


