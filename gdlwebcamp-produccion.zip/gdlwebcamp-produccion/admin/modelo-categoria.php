<?php
    //No me dejaba entrar al login de la nada, y al poner esto, se resolvió.
    error_reporting(E_ALL ^ E_NOTICE);

    //Para que se conecte a la base de datos
    include_once 'funciones/funciones.php';

    //Ping revisa que se haga conexión a la BD
    // if($conn->ping()) {
    //     echo "Conectado";
    // } else {
    //     echo "No";
    // }

    $nombre_categoria = $_POST['nombre-categoria'];
    $icono = $_POST['icono'];
    $id_registro = $_POST['id_registro'];

    //Cuando se quiera añadir una categoría. Se usa el input hidden como referencia para saber que se insertó info.
    if($_POST['registro'] == 'nuevo'){
        //DIE hace que deje de ejecutarse el código posterior a su llamado
        // die(json_encode($_POST));

        try {
            $stmt = $conn->prepare('INSERT INTO categoria_evento (cat_evento, icono) VALUES (?, ?)');
            $stmt->bind_param('ss', $nombre_categoria, $icono);
            $stmt->execute();
            $id_insertado = $stmt->insert_id;
            if($stmt->affected_rows) {
                $respuesta = array(
                    'respuesta' => 'exito',
                    'id_insertado' => $id_insertado
                );
            } else {
                $respuesta = array(
                    'respuesta' => 'error'
                );
            }
            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            $respuesta = array(
                'respuesta' => $e->getMessage()
            );
        }
        die(json_encode($respuesta));
    }

    //Cuando se quiere editar una categoría
    if($_POST['registro'] == 'actualizar') {
        // die(json_encode($_POST));

        try {
            $stmt = $conn->prepare("UPDATE categoria_evento SET cat_evento = ?, icono = ?, editado = NOW() WHERE id_categoria = ?");
            $stmt->bind_param("ssi", $nombre_categoria, $icono, $id_registro);
            $stmt->execute();
            // if($id_registro > 0)
            if($stmt->affected_rows) {
                $respuesta = array(
                    'respuesta' => 'exito',
                    'id_actualizado' => $id_registro
                );
            } else {
                $respuesta = array(
                    'respuesta' => 'error'
                );
            }
            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            $respuesta = array(
                'respuesta' => $e->getMessage()
            );
        }

        die(json_encode($respuesta));
    }

    //Eliminar una categoría
    if($_POST['registro'] == 'eliminar') {
        // die(json_encode($_POST));

        $id_borrar = $_POST['id'];

        try {
            $stmt = $conn->prepare('DELETE FROM categoria_evento WHERE id_categoria = ?');
            $stmt->bind_param('i', $id_borrar);
            $stmt->execute();
            if($stmt->affected_rows) {
                $respuesta = array(
                    'respuesta' => 'exito',
                    'id_eliminado' => $id_borrar
                );
            } else {
                $respuesta = array(
                    'respuesta' => 'error'
                );
            }
            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            $respuesta = array(
                'respuesta' => $e->getMessage()
            );
        }
        die(json_encode($respuesta));
    }
    
?>