<?php
    //No me dejaba entrar al login de la nada, y al poner esto, se resolvió.
    error_reporting(E_ALL ^ E_NOTICE);

    //Para que se conecte a la base de datos
    include_once 'funciones/funciones.php';

    //Ping revisa que se haga conexión a la BD
    // if($conn->ping()) {
    //     echo "Conectado";
    // } else {
    //     echo "No";
    // }

    $nombre = $_POST['nombre-invitado'];
    $apellido = $_POST['apellido-invitado'];
    $biografia = $_POST['biografia-invitado'];
    $id_registro = $_POST['id_registro'];

    //Cuando se quiera añadir una categoría. Se usa el input hidden como referencia para saber que se insertó info.
    if($_POST['registro'] == 'nuevo'){

        // $respuesta = array(
        //     'post' => $_POST,
        //     //Con esto se accede a los archivos de un formulario
        //     'file' => $_FILES
        // );
        // die(json_encode($respuesta));

        //Esta va a ser la ubicación en la cual se guardarán los archivos
        $directorio = "../img/invitados/";
        //is_dir revisa que un directorio exista
        if(!is_dir($directorio)) {
            //esto crea un directorio, con permisos 0755 y recursivo
            //Recursividad: al crearse nuevos archivos dentro de la carpeta $directorio, tendrán los mismos permisos de esta
            mkdir($directorio, 0755, true);
        }

        //Para mover los archivos de la ubicación temporal que le da PHP, a nuestra ubicación deseada
        //2 parámetros: ubicación actual, ubicación deseada
        if(move_uploaded_file($_FILES['archivo_imagen']['tmp_name'], $directorio . $_FILES['archivo_imagen']['name'])) {
            $imagen_url = $_FILES['archivo_imagen']['name'];
            $imagen_resultado = "Se subió correctamente";
        } else {
            $respuesta = array(
                'respuesta' => error_get_last()
            );
        }

        try {
            $stmt = $conn->prepare('INSERT INTO invitados (nombre_invitado, apellido_invitado, descripcion, url_imagen) VALUES (?, ?, ?, ?)');
            $stmt->bind_param('ssss', $nombre, $apellido, $biografia, $imagen_url);
            $stmt->execute();
            $id_insertado = $stmt->insert_id;
            if($stmt->affected_rows) {
                $respuesta = array(
                    'respuesta' => 'exito',
                    'id_insertado' => $id_insertado,
                    'resultado_img' => $imagen_resultado
                );
            } else {
                $respuesta = array(
                    'respuesta' => 'error'
                );
            }
            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            $respuesta = array(
                'respuesta' => $e->getMessage()
            );
        }
        die(json_encode($respuesta));
    }

    //Cuando se quiere editar una categoría
    if($_POST['registro'] == 'actualizar') {
        // $respuesta = array(
        //     'post' => $_POST,
        //     //Con esto se accede a los archivos de un formulario
        //     'file' => $_FILES
        // );
        // die(json_encode($respuesta));

        $directorio = "../img/invitados/";
        //is_dir revisa que un directorio exista
        if(!is_dir($directorio)) {
            mkdir($directorio, 0755, true);
        }

        if(move_uploaded_file($_FILES['archivo_imagen']['tmp_name'], $directorio . $_FILES['archivo_imagen']['name'])) {
            $imagen_url = $_FILES['archivo_imagen']['name'];
            $imagen_resultado = "Se subió correctamente";
        } else {
            $respuesta = array(
                'respuesta' => error_get_last()
            );
        }

        try {
            //Si el tamaño de imagen es mayor a cero, es porque el usuario sí subió algo
            if($_FILES['archivo_imagen']['size'] > 0) {
                //Cuando cambia la imagen
                $stmt = $conn->prepare("UPDATE invitados SET nombre_invitado = ?, apellido_invitado = ?, descripcion = ?, url_imagen = ? WHERE invitado_id = ?");
                $stmt->bind_param('ssssi', $nombre, $apellido, $biografia, $imagen_url, $id_registro);
            } else {
                //Cuando no se actualiza la imagen
                $stmt = $conn->prepare("UPDATE invitados SET nombre_invitado = ?, apellido_invitado = ?, descripcion = ? WHERE invitado_id = ?");
                $stmt->bind_param('sssi', $nombre, $apellido, $biografia, $id_registro);
            }
            $estado = $stmt->execute();
            // if($id_registro > 0)
            if($estado == true) {
                $respuesta = array(
                    'respuesta' => 'exito',
                    'id_actualizado' => $id_registro
                );
            } else {
                $respuesta = array(
                    'respuesta' => 'error'
                );
            }
            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            $respuesta = array(
                'respuesta' => $e->getMessage()
            );
        }

        die(json_encode($respuesta));
    }

    //Eliminar una categoría
    if($_POST['registro'] == 'eliminar') {
        // die(json_encode($_POST));

        $id_borrar = $_POST['id'];

        try {
            $stmt = $conn->prepare('DELETE FROM invitados WHERE invitado_id = ?');
            $stmt->bind_param('i', $id_borrar);
            $stmt->execute();
            if($stmt->affected_rows) {
                $respuesta = array(
                    'respuesta' => 'exito',
                    'id_eliminado' => $id_borrar
                );
            } else {
                $respuesta = array(
                    'respuesta' => 'error'
                );
            }
            $stmt->close();
            $conn->close();
        } catch (Exception $e) {
            $respuesta = array(
                'respuesta' => $e->getMessage()
            );
        }
        die(json_encode($respuesta));
    }
    
?>